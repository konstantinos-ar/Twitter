package mainPackage;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONException;
import org.json.JSONObject;

import sun.net.www.http.HttpClient;
import sun.rmi.runtime.Log;

public class JSONfunctions {

	public static JSONObject getJSONfromURL(String url){
        InputStream is = null;
        String result = "";
        JSONObject jArray = null;
        String u = "konstantinos.ar@gmail.com";
        String p = "arvanitis3210689";
        String content = null;
 
        // Download JSON data from URL
        try{
                DefaultHttpClient httpclient = new DefaultHttpClient();
               /* HttpPost httppost = new HttpPost(url);
                HttpResponse response = httpclient.execute(httppost);
                HttpEntity entity = response.getEntity();
                is = entity.getContent();*/
                
                /* Creates a new authenticator */
                GoogleAuthenticator authenticator = new GoogleAuthenticator(u, p, httpclient);

                /* Creates a new Google Trends Client */
                GoogleTrendsClient client = new GoogleTrendsClient(authenticator, httpclient);
                GoogleTrendsRequest request = new GoogleTrendsRequest("bank of america debt");

                /* Here the default request params can be modified with getter/setter methods */
                content = client.execute(request);
 
        }catch(Exception e){
                //Log.e("log_tag", "Error in http connection "+e.toString());
        }
 
        // Convert response to string
  /*      try{
                BufferedReader reader = new BufferedReader(new InputStreamReader(is,"iso-8859-1"),8);
                StringBuilder sb = new StringBuilder();
                String line = null;
                while ((line = reader.readLine()) != null) {
                        sb.append(line + "\n");
                }
                is.close();
                result=sb.toString();
        }catch(Exception e){
               // Log.e("log_tag", "Error converting result "+e.toString());
        }
 */
        try{
 
       /* 	if (!result.startsWith("{\"query\":{"))
        	{
        		result.replace("google.visualization.Query.setResponse(", "{");
        		result.replace(");", "}");
        	}*/
            jArray = new JSONObject(content);           
        }catch(JSONException e){
               // Log.e("log_tag", "Error parsing data "+e.toString());
        }
 
        return jArray;
    }
}
