package mainPackage;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpRequestBase;
import org.json.JSONException;
import org.json.JSONObject;

import exceptions.GoogleAuthenticatorException;
import exceptions.GoogleTrendsClientException;
import exceptions.GoogleTrendsRequestException;

public class GoogleTrendsClient {

  private final GoogleAuthenticator authenticator;
  private final HttpClient client;
  JSONObject jArray = null;

  public GoogleTrendsClient(GoogleAuthenticator authenticator, HttpClient client) {
    this.authenticator = authenticator;
    this.client = client;
  }

  public String execute(GoogleTrendsRequest request) throws GoogleTrendsClientException {
    String html = null;
    try {
      if (!authenticator.isLoggedIn()) {
        authenticator.authenticate();
      }
      Logger.getLogger(GoogleConfigurator.getLoggerPrefix()).log(Level.FINE, "Query: {0}", request.build().toString());

      HttpRequestBase httpRequest = request.build();
      HttpResponse response = client.execute(httpRequest);
      html = GoogleUtils.toString(response.getEntity().getContent());
      jArray = new JSONObject(html);
      httpRequest.releaseConnection();

      Pattern p = Pattern.compile(GoogleConfigurator.getConfiguration().getString("google.trends.client.reError"), Pattern.CASE_INSENSITIVE);
      Matcher matcher = p.matcher(html);
      if (matcher.find()) {
        throw new GoogleTrendsClientException("*** You are running too fast man! Looks like you reached your quota limit. Wait a while and slow it down with the '-S' option! *** ");
      }
    } catch (GoogleAuthenticatorException ex) {
      throw new GoogleTrendsClientException(ex);
    } catch (ClientProtocolException ex) {
      throw new GoogleTrendsClientException(ex);
    } catch (IOException ex) {
      throw new GoogleTrendsClientException(ex);
    } catch (ConfigurationException ex) {
      throw new GoogleTrendsClientException(ex);
    } catch (GoogleTrendsRequestException ex) {
      throw new GoogleTrendsClientException(ex);
    } catch (JSONException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

    return html;
  }
}
